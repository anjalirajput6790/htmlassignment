# Personal Portfolio Website — WebDev Lab Assignment 2

## Files
- `index.html` — portfolio page structure
- `style.css` — external stylesheet with all styling
- `profile.svg` — local profile illustration

## How to run
1. Keep all three files in the same folder.
2. Open `index.html` in a web browser.
3. Replace “Your Name” with your name and edit the skills/projects as needed.

## Assignment requirements included
- External CSS linked from HTML
- Consistent blue/white color theme and Google Font
- Styled navigation with hover effects
- Spacing, borders, and shadows using the CSS box model
- Skills table with borders and alternating row colors
- Styled button with hover effect
- Sticky navigation and fixed Back to Top button
- Horizontal separators and responsive layout

Note: The contact form is a front-end demo and will not send messages until connected to a form-handling service.
